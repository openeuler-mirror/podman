These are definitions and scripts consumed by packer to produce the
various distribution images used for CI testing.
