// +build !linux

package libpod

type containerPlatformState struct{}
