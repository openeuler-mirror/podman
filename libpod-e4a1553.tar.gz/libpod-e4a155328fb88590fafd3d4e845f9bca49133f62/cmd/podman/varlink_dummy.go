// +build !varlink

package main

import (
	"github.com/urfave/cli"
)

var varlinkCommand *cli.Command
