package docs

//go:generate go run varlink/apidoc.go ../cmd/podman/varlink/io.podman.varlink ../API.md
